from setuptools import setup, find_packages  # Make sure this line is at the top

# Read the content of README.md for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="my_calculator_jy",  # Change this to your unique name
    version="1.0.1",  # Update the version
    packages=find_packages(),
    description="A comprehensive calculator module for various mathematical operations",
    long_description=long_description,  # Include the long description from README.md
    long_description_content_type="text/markdown",  # Specify that the README is in Markdown
    author="Jewon Yeon",
    author_email="jewon.yeon@sjsu.edu",
    url="https://github.com/yeon971105/my_calculator",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
